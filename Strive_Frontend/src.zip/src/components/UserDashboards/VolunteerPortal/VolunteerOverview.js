import React from 'react';

export default function VolunteerOverview() {
  return (
    <div>
      <h2>Your Volunteer Overview</h2>
      <p>No tasks yet — start volunteering soon!</p>
    </div>
  );
}
