import React from 'react';
import './MediaCenter.css';

export default function MediaCenter() {
  return (
    <div className="OtherWorkPage">
      <h1>Media Center</h1>
      <p>Explore our additional programs and partnerships.</p>
    </div>
  );
}
