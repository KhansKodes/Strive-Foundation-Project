export async function getDonations() {
  return [
    { id: 1, date: '2025-06-30', amount: 100 },
    { id: 2, date: '2025-07-01', amount: 250 }
  ];
}
