export async function getAppointments() {
  return [
    { id: 1, date: '2025-07-15', description: 'General Checkup' },
    { id: 2, date: '2025-07-20', description: 'Therapy Session' }
  ];
}
