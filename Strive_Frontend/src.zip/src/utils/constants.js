export const ROLES = {
  PATIENT: 'patient',
  DONOR: 'donor',
  VOLUNTEER: 'volunteer'
};
