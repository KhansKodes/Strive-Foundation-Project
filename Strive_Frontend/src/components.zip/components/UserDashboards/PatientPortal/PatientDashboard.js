import React, { useEffect, useMemo, useState } from "react";
import { getAppointments } from "../../../services/patientService";
import AppointmentCard from "./AppointmentCard";
import PortalLayout from "../PortalLayout/PortalLayout";
import { patientMenu } from "../PortalLayout/menuConfig";

export default function PatientDashboard() {
  const [apps, setApps] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    getAppointments()
      .then((res) => {
        if (!mounted) return;
        if (!res || res.length === 0) {
          const dummy = [
            { id: 1, date: "2025-09-05 10:00", description: "Physiotherapy Session", doctor: "Dr. Patel", status: "Upcoming" },
            { id: 2, date: "2025-09-12 14:00", description: "Occupational Therapy", doctor: "Dr. Kim", status: "Upcoming" },
            { id: 3, date: "2025-08-22 09:00", description: "Neurology Check-in", doctor: "Dr. Gomez", status: "Completed" },
          ];
          setApps(dummy);
        } else {
          setApps(res);
        }
      })
      .catch(() => {
        if (!mounted) return;
        const dummy = [
          { id: 1, date: "2025-09-05 10:00", description: "Physiotherapy Session", doctor: "Dr. Patel", status: "Upcoming" },
          { id: 2, date: "2025-09-12 14:00", description: "Occupational Therapy", doctor: "Dr. Kim", status: "Upcoming" },
          { id: 3, date: "2025-08-22 09:00", description: "Neurology Check-in", doctor: "Dr. Gomez", status: "Completed" },
        ];
        setApps(dummy);
      })
      .finally(() => mounted && setLoading(false));
    return () => { mounted = false; };
  }, []);

  const nextAppt = useMemo(() => apps.find((a) => a.status === "Upcoming"), [apps]);

  return (
    <PortalLayout title="Patient Portal" menu={patientMenu} initialActiveKey="overview">
      {(active) => {
        if (active === "appointments") {
          return (
            <>
              <div className="stats-grid">
                <div className="stat-card">
                  <div className="stat-label">Total Appointments</div>
                  <div className="stat-value">{apps.length}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Upcoming</div>
                  <div className="stat-value">{apps.filter(a => a.status === 'Upcoming').length}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Completed</div>
                  <div className="stat-value">{apps.filter(a => a.status === 'Completed').length}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Next Doctor</div>
                  <div className="stat-value">{nextAppt?.doctor || '-'}</div>
                </div>
              </div>

              <div className="portal-card">
                <h2>Appointments</h2>
                {loading && <p className="item-sub">Loading...</p>}
                {!loading && apps.length === 0 && (
                  <p className="item-sub">No appointments yet.</p>
                )}
                {!loading && apps.length > 0 && (
                  <div className="mt-16">
                    {apps.map((a) => <AppointmentCard key={a.id} appointment={a} />)}
                  </div>
                )}
              </div>
            </>
          );
        }
        if (active === "records") {
          return <div className="portal-card">Medical records area — (placeholder).</div>;
        }
        if (active === "messages") {
          return <div className="portal-card">Secure messages — (placeholder).</div>;
        }
        if (active === "settings") {
          return <div className="portal-card">Patient settings — (placeholder).</div>;
        }
        // overview
        return (
          <>
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-label">Next Appointment</div>
                <div className="stat-value">{nextAppt?.date || '—'}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Doctor</div>
                <div className="stat-value">{nextAppt?.doctor || '—'}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Upcoming</div>
                <div className="stat-value">{apps.filter(a => a.status === 'Upcoming').length}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Completed</div>
                <div className="stat-value">{apps.filter(a => a.status === 'Completed').length}</div>
              </div>
            </div>

            <div className="cards-grid">
              <section className="portal-card col-8">
                <h2 className="section-title">Upcoming & Recent</h2>
                {apps.map((a) => <AppointmentCard key={a.id} appointment={a} />)}
              </section>
              <section className="portal-card col-4">
                <h2 className="section-title">Care Tips</h2>
                <div className="item-row">
                  <div>
                    <div className="item-title">Daily Stretching</div>
                    <div className="item-sub">5–10 minutes morning & evening</div>
                  </div>
                  <span className="badge info">Recommended</span>
                </div>
                <div className="item-row">
                  <div>
                    <div className="item-title">Hydration</div>
                    <div className="item-sub">6–8 glasses per day</div>
                  </div>
                  <span className="badge">Tip</span>
                </div>
                <div className="item-row">
                  <div>
                    <div className="item-title">Rest & Recovery</div>
                    <div className="item-sub">Aim for 8 hours sleep</div>
                  </div>
                  <span className="badge success">Healthy</span>
                </div>
              </section>
            </div>
          </>
        );
      }}
    </PortalLayout>
  );
}
