import React from 'react';

export default function AppointmentCard({ appointment }) {
  const status = appointment.status || 'Upcoming';
  return (
    <div className="item-row">
      <div>
        <div className="item-title">{appointment.description}</div>
        <div className="item-sub">{appointment.date} • {appointment.doctor || '—'}</div>
      </div>
      <span className={`badge ${status === 'Upcoming' ? 'info' : 'success'}`}>{status}</span>
    </div>
  );
}
