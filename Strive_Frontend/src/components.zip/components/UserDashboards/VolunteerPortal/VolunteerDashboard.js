import React, { useMemo, useState } from "react";
import VolunteerOverview from "./VolunteerOverview";
import PortalLayout from "../PortalLayout/PortalLayout";
import { volunteerMenu } from "../PortalLayout/menuConfig";

export default function VolunteerDashboard() {
  const [tasks] = useState([
    { id: 1, title: "Pack care kits", due: "Sep 03, 10:00", location: "Center A", status: "Assigned" },
    { id: 2, title: "Call donor leads", due: "Sep 04, 14:00", location: "Remote", status: "Assigned" },
    { id: 3, title: "Event setup", due: "Sep 05, 08:00", location: "Hall B", status: "Planned" },
    { id: 4, title: "Distribute flyers", due: "Sep 07, 12:00", location: "Downtown", status: "Completed" },
  ]);

  const counts = useMemo(() => ({
    total: tasks.length,
    assigned: tasks.filter(t => t.status === 'Assigned').length,
    completed: tasks.filter(t => t.status === 'Completed').length,
  }), [tasks]);

  return (
    <PortalLayout title="Volunteer Portal" menu={volunteerMenu} initialActiveKey="overview">
      {(active) => {
        if (active === "tasks") {
          return (
            <>
              <div className="stats-grid">
                <div className="stat-card"><div className="stat-label">Total Tasks</div><div className="stat-value">{counts.total}</div></div>
                <div className="stat-card"><div className="stat-label">Assigned</div><div className="stat-value">{counts.assigned}</div></div>
                <div className="stat-card"><div className="stat-label">Completed</div><div className="stat-value">{counts.completed}</div></div>
                <div className="stat-card"><div className="stat-label">Next</div><div className="stat-value">{tasks[0]?.title || '—'}</div></div>
              </div>
              <div className="portal-card">
                <h2>Task List</h2>
                <div className="mt-16">
                  {tasks.map(t => (
                    <div className="item-row" key={t.id}>
                      <div>
                        <div className="item-title">{t.title}</div>
                        <div className="item-sub">Due {t.due} • {t.location}</div>
                      </div>
                      <span className={`badge ${t.status === 'Assigned' ? 'info' : t.status === 'Completed' ? 'success' : ''}`}>{t.status}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          );
        }
        if (active === "schedule") {
          return (
            <div className="portal-card">
              <h2>Schedule</h2>
              <table className="table mt-16">
                <thead>
                  <tr><th>Date</th><th>Task</th><th>Location</th><th>Status</th></tr>
                </thead>
                <tbody>
                  {tasks.map(t => (
                    <tr key={t.id}>
                      <td>{t.due}</td>
                      <td>{t.title}</td>
                      <td>{t.location}</td>
                      <td><span className={`badge ${t.status === 'Assigned' ? 'info' : t.status === 'Completed' ? 'success' : ''}`}>{t.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        }
        if (active === "messages") {
          return <div className="portal-card">Messages — (placeholder).</div>;
        }
        if (active === "settings") {
          return <div className="portal-card">Volunteer settings — (placeholder).</div>;
        }
        // overview
        return (
          <>
            <div className="stats-grid">
              <div className="stat-card"><div className="stat-label">Total Tasks</div><div className="stat-value">{counts.total}</div></div>
              <div className="stat-card"><div className="stat-label">Assigned</div><div className="stat-value">{counts.assigned}</div></div>
              <div className="stat-card"><div className="stat-label">Completed</div><div className="stat-value">{counts.completed}</div></div>
              <div className="stat-card"><div className="stat-label">Next</div><div className="stat-value">{tasks[0]?.title || '—'}</div></div>
            </div>
            <VolunteerOverview tasks={tasks} />
          </>
        );
      }}
    </PortalLayout>
  );
}
