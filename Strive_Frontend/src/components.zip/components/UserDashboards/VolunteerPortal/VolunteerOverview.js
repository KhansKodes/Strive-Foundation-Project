import React from 'react';

export default function VolunteerOverview({ tasks = [] }) {
  return (
    <div className="portal-card">
      <h2 className="section-title">Today at a glance</h2>
      {tasks.length === 0 ? (
        <p className="item-sub">No tasks yet — start volunteering soon!</p>
      ) : (
        tasks.slice(0, 5).map((t) => (
          <div className="item-row" key={t.id}>
            <div>
              <div className="item-title">{t.title}</div>
              <div className="item-sub">Due {t.due} • {t.location}</div>
            </div>
            <span className={`badge ${t.status === 'Assigned' ? 'info' : t.status === 'Completed' ? 'success' : ''}`}>{t.status}</span>
          </div>
        ))
      )}
    </div>
  );
}
