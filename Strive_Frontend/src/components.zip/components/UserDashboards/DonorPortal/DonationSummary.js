import React from 'react';

export default function DonationSummary({ donation }) {
  const amount = Number(donation.amount || 0).toLocaleString();
  const status = donation.status || 'Completed';
  const campaign = donation.campaign || 'General Fund';
  return (
    <div className="item-row">
      <div>
        <div className="item-title">${amount} • {campaign}</div>
        <div className="item-sub">{donation.date}</div>
      </div>
      <span className={`badge ${status === 'Completed' ? 'success' : ''}`}>{status}</span>
    </div>
  );
}
