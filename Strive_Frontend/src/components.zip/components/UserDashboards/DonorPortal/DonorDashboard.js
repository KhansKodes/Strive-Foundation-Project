import React, { useEffect, useMemo, useState } from "react";
import { getDonations } from "../../../services/donorService";
import DonationSummary from "./DonationSummary";
import PortalLayout from "../PortalLayout/PortalLayout";
import { donorMenu } from "../PortalLayout/menuConfig";

export default function DonorDashboard() {
  const [dons, setDons] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let mounted = true;
    setLoading(true);
    getDonations()
      .then((res) => {
        if (!mounted) return;
        if (!res || res.length === 0) {
          const dummy = [
            { id: 1, date: "2025-08-20", amount: 250, campaign: "SMA Research", status: "Completed" },
            { id: 2, date: "2025-07-05", amount: 100, campaign: "Therapy Support", status: "Completed" },
            { id: 3, date: "2025-06-15", amount: 50, campaign: "Family Aid", status: "Completed" },
            { id: 4, date: "2025-05-10", amount: 25, campaign: "Awareness", status: "Completed" },
          ];
          setDons(dummy);
        } else {
          setDons(res);
        }
      })
      .catch(() => {
        if (!mounted) return;
        const dummy = [
          { id: 1, date: "2025-08-20", amount: 250, campaign: "SMA Research", status: "Completed" },
          { id: 2, date: "2025-07-05", amount: 100, campaign: "Therapy Support", status: "Completed" },
          { id: 3, date: "2025-06-15", amount: 50, campaign: "Family Aid", status: "Completed" },
          { id: 4, date: "2025-05-10", amount: 25, campaign: "Awareness", status: "Completed" },
        ];
        setDons(dummy);
      })
      .finally(() => mounted && setLoading(false));
    return () => { mounted = false; };
  }, []);

  const totals = useMemo(() => {
    const totalAmount = dons.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
    const gifts = dons.length;
    const avg = gifts ? Math.round((totalAmount / gifts) * 100) / 100 : 0;
    const ytd = dons
      .filter((d) => String(d.date).startsWith("2025"))
      .reduce((s, d) => s + (Number(d.amount) || 0), 0);
    return { totalAmount, gifts, avg, ytd };
  }, [dons]);

  return (
    <PortalLayout title="Donor Portal" menu={donorMenu} initialActiveKey="overview">
      {(active) => {
        if (active === "donations") {
          return (
            <>
              <div className="stats-grid">
                <div className="stat-card">
                  <div className="stat-label">Total Given</div>
                  <div className="stat-value">${totals.totalAmount.toLocaleString()}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Gifts</div>
                  <div className="stat-value">{totals.gifts}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Average Gift</div>
                  <div className="stat-value">${totals.avg.toLocaleString()}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">YTD</div>
                  <div className="stat-value">${totals.ytd.toLocaleString()}</div>
                </div>
              </div>

              <div className="portal-card">
                <h2>Your Donations</h2>
                {loading && <p className="item-sub">Loading...</p>}
                {!loading && dons.length === 0 && (
                  <p className="item-sub">No donations yet.</p>
                )}
                {!loading && dons.length > 0 && (
                  <div className="mt-16">
                    {dons.map((d) => (
                      <DonationSummary key={d.id} donation={d} />
                    ))}
                  </div>
                )}
              </div>
            </>
          );
        }
        if (active === "receipts") {
          return (
            <div className="portal-card">
              <h2>Receipts</h2>
              <table className="table mt-16">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Campaign</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Receipt</th>
                  </tr>
                </thead>
                <tbody>
                  {dons.map((d) => (
                    <tr key={d.id}>
                      <td>{d.date}</td>
                      <td>{d.campaign || "General Fund"}</td>
                      <td>${Number(d.amount).toLocaleString()}</td>
                      <td><span className="badge success">Paid</span></td>
                      <td><button className="logout-btn">Download</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        }
        if (active === "impact") {
          return (
            <div className="portal-card">
              <h2>Your Impact</h2>
              <p className="item-sub">Thanks to your support, we are reaching goals faster.</p>
              <div className="mt-16">
                <div className="item-row">
                  <div>
                    <div className="item-title">Therapy Sessions Funded</div>
                    <div className="item-sub">Target: 100 sessions</div>
                  </div>
                  <div style={{ minWidth: 220 }}>
                    <div className="progress"><span style={{ width: "72%" }} /></div>
                    <div className="item-sub" style={{ textAlign: "right" }}>72%</div>
                  </div>
                </div>
                <div className="item-row">
                  <div>
                    <div className="item-title">Families Supported</div>
                    <div className="item-sub">Target: 50 families</div>
                  </div>
                  <div style={{ minWidth: 220 }}>
                    <div className="progress"><span style={{ width: "54%" }} /></div>
                    <div className="item-sub" style={{ textAlign: "right" }}>54%</div>
                  </div>
                </div>
                <div className="item-row">
                  <div>
                    <div className="item-title">Awareness Campaign Reach</div>
                    <div className="item-sub">Target: 1,000,000 impressions</div>
                  </div>
                  <div style={{ minWidth: 220 }}>
                    <div className="progress"><span style={{ width: "88%" }} /></div>
                    <div className="item-sub" style={{ textAlign: "right" }}>88%</div>
                  </div>
                </div>
              </div>
            </div>
          );
        }
        if (active === "settings") {
          return <div className="portal-card">Donor settings — coming soon.</div>;
        }
        // overview
        return (
          <>
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-label">Total Given</div>
                <div className="stat-value">${totals.totalAmount.toLocaleString()}</div>
                <div className="stat-trend">+12% vs last year</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Gifts</div>
                <div className="stat-value">{totals.gifts}</div>
                <div className="stat-trend">+1 new this month</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">YTD</div>
                <div className="stat-value">${totals.ytd.toLocaleString()}</div>
                <div className="stat-trend">On track</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Next Milestone</div>
                <div className="stat-value">$1,000</div>
                <div className="stat-trend down">$575 to go</div>
              </div>
            </div>

            <div className="cards-grid">
              <section className="portal-card col-8">
                <h2 className="section-title">Recent Donations</h2>
                {dons.slice(0, 5).map((d) => (
                  <DonationSummary key={d.id} donation={d} />
                ))}
              </section>

              <section className="portal-card col-4">
                <h2 className="section-title">Impact Highlights</h2>
                <div className="item-row">
                  <div>
                    <div className="item-title">Therapy Sessions</div>
                    <div className="item-sub">72/100 funded</div>
                  </div>
                  <span className="badge success">+3 this week</span>
                </div>
                <div className="item-row">
                  <div>
                    <div className="item-title">Families Supported</div>
                    <div className="item-sub">27/50 supported</div>
                  </div>
                  <span className="badge info">New story</span>
                </div>
                <div className="item-row">
                  <div>
                    <div className="item-title">Awareness Reach</div>
                    <div className="item-sub">880k/1M reached</div>
                  </div>
                  <span className="badge">+40k</span>
                </div>
              </section>
            </div>
          </>
        );
      }}
    </PortalLayout>
  );
}
