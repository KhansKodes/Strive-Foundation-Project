import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../../hooks/useAuth";
import { FiMenu, FiLogOut, FiBell, FiSearch } from "react-icons/fi";

export default function Topbar({ title, sidebarOpen, onToggleSidebar }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const fullName = user?.profile?.fullName || "User";
  const initials = fullName
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const handleLogout = () => {
    logout();
    nav("/login");
  };

  return (
    <header className="portal-topbar">
      <button className="menu-toggle" onClick={onToggleSidebar} aria-label="Toggle sidebar">
        <FiMenu />
      </button>

      <div className="topbar-center">
        <div className="brand-title" aria-live="polite">{title}</div>
        <div className="search-wrap">
          <FiSearch className="search-ico" />
          <input className="search-input" placeholder="Search..." aria-label="Search" />
        </div>
      </div>

      <div className="topbar-right">
        <button className="icon-btn" aria-label="Notifications">
          <FiBell />
          <span className="dot" />
        </button>
        <div className="avatar" title={fullName} aria-label={`Profile ${fullName}`}>{initials}</div>
        <button className="logout-btn" onClick={handleLogout} aria-label="Logout">
          <FiLogOut />
          <span className="hide-sm">Logout</span>
        </button>
      </div>
    </header>
  );
}
