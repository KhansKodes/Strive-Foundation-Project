import React from "react";
import { FiX } from "react-icons/fi";

export default function Sidebar({ open, menu = [], activeKey, onChange, onClose }) {
  return (
    <aside className={`portal-sidebar ${open ? "open" : "closed"}`} aria-hidden={!open}>
      <div className="sidebar-head">
        <span className="brand">STRIVE</span>
      </div>

      <nav className="sidebar-nav">
        {menu.map((m) => (
          <button
            key={m.key}
            className={`nav-item ${activeKey === m.key ? "active" : ""}`}
            onClick={() => onChange(m.key)}
            title={m.label}
          >
            {m.icon && <span className="nav-ico">{m.icon}</span>}
            <span className="nav-label">{m.label}</span>
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        <span className="muted">v1.0</span>
      </div>
    </aside>
  );
}
